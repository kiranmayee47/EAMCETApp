package com.example.eamcetapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class clg3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clg3);
    }
}
